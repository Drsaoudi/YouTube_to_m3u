<?php

namespace Core\Request;

class Exception extends \Exception
{

}