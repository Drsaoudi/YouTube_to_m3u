<?php

namespace Core;

class Session extends \Phpfox_Session
{

}