<?php

namespace Core\Storage;

class Objects extends \Core\Objectify
{
    public $id;
    public $key;
    public $value;
    public $order;
    public $data_size;
}