<?php

namespace Core\Log;


class NullLogger extends AbstractLogger
{

    public function log($level, $message, $context = [])
    {
        // TODO: Implement log() method.
    }
}