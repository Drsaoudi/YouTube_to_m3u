<?php

return [
    'PHPfox_Core'    => [
        'name' => 'Core',
        'dir'  => 'core',
    ],
    'PHPfox_Flavors' => [
        'name' => 'Flavors',
        'dir'  => 'core-flavors',
    ],
    'Core_Photos'    => [
        'name' => 'Photos',
        'dir'  => 'core-photos',
    ],
];