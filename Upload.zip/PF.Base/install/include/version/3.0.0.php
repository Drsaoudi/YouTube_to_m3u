<?php

$this->_upgradeDatabase('3.0.0');

$bCompleted = true;

?>