<?php

$this->_upgradeDatabase('3.5.0');
$bCompleted = true;

?>