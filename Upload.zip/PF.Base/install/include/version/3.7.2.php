<?php

$this->_upgradeDatabase('3.7.2');
$bCompleted = true;

?>