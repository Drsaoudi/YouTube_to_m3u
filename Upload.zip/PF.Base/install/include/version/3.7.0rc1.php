<?php

$this->_upgradeDatabase('3.7.0rc1');
$bCompleted = true;

?>