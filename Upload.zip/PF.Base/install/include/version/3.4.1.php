<?php

$this->_upgradeDatabase('3.4.1');

$bCompleted = true;

?>