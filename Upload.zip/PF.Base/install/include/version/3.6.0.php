<?php

$this->_upgradeDatabase('3.6.0');
$bCompleted = true;

?>