<?php

$this->_upgradeDatabase('3.7.4');
$bCompleted = true;

?>