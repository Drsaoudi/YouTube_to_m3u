<?php

$this->_upgradeDatabase('3.0.2');

$bCompleted = true;

?>