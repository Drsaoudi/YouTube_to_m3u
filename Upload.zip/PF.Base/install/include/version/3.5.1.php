<?php

$this->_upgradeDatabase('3.5.1');
$bCompleted = true;

?>