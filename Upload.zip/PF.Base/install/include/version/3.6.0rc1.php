<?php

$this->_upgradeDatabase('3.6.0rc1');
$bCompleted = true;

?>