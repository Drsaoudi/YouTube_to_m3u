<?php
$this->_upgradeDatabase('3.7.6');
$bCompleted = true;
?>
