<?php
/** $Id: $ **/
defined('PHPFOX') or exit('NO DICE!');
?>