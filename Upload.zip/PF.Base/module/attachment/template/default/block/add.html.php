<?php
/**
 * [PROWEBBER.ru - 2019]
 * 
 * @copyright		[PHPFOX_COPYRIGHT]
 * @author  		Raymond Benc
 * @package  		Module_Attachment
 * @version 		$Id: add.html.php 2525 2011-04-13 18:03:20Z Raymond_Benc $
 */

defined('PHPFOX') or exit('NO DICE!');

?>
{module name='attachment.upload' sCategoryId=$sCategoryId id=$id}