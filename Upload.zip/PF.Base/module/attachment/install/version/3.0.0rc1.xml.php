<upgrade>
	<hooks>
		<hook>
			<module_id>attachment</module_id>
			<hook_type>component</hook_type>
			<module>attachment</module>
			<call_name>attachment.component_block_share_clean</call_name>
			<added>1319729453</added>
			<version_id>3.0.0rc1</version_id>
			<value />
		</hook>
	</hooks>
</upgrade>