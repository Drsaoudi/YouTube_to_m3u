<?php
/**
 * [PROWEBBER.ru - 2019]
 */

defined('PHPFOX') or exit('NO DICE!');

/**
 *
 *
 * @copyright		[PHPFOX_COPYRIGHT]
 * @author  		Miguel Espinoza
 * @package  		Module_Contact
 * @version 		$Id: phpfox.class.php 982 2009-09-16 08:11:36Z Raymond_Benc $
 */
class Module_Contact
{
	public static $aTables = array(
		'contact_category'
	);
}