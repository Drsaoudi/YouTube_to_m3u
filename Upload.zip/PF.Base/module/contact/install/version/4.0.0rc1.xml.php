<upgrade>
	<phpfox_update_menus>
		<menu>
			<module_id>contact</module_id>
			<parent_var_name />
			<m_connection>footer</m_connection>
			<var_name>menu_contact</var_name>
			<ordering>15</ordering>
			<url_value>contact</url_value>
			<version_id>2.0.0alpha1</version_id>
			<disallow_access />
			<module>contact</module>
			<value />
		</menu>
	</phpfox_update_menus>
</upgrade>