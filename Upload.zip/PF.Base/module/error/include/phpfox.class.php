<?php
/**
 * [PROWEBBER.ru - 2019]
 */

defined('PHPFOX') or exit('NO DICE!');

/**
 * 
 * 
 * @copyright		[PHPFOX_COPYRIGHT]
 * @author  		Raymond Benc
 * @package  		Module_Error
 * @version 		$Id: phpfox.class.php 1121 2009-10-01 12:59:13Z Raymond_Benc $
 */
class Module_Error 
{	
	public static $aTables = array();
}