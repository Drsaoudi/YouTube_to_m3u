<?php
defined('PHPFOX') or exit('NO DICE!');
?>

{_p var='The page may only be visible to an audience you\'re not in.'}