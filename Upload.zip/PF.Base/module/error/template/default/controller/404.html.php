<?php
defined('PHPFOX') or exit('NO DICE!');
?>

{_p var='the_page_you_are_looking_for_cannot_be_found'}