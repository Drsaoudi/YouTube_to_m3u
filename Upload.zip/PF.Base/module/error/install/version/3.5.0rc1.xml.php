<upgrade>
	<hooks>
		<hook>
			<module_id>error</module_id>
			<hook_type>controller</hook_type>
			<module>error</module>
			<call_name>error.component_controller_notfound_1</call_name>
			<added>1361180401</added>
			<version_id>3.5.0rc1</version_id>
			<value />
		</hook>
	</hooks>
</upgrade>