
$Core.init();