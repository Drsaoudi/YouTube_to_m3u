<?php
// Software Name
$name = 'phpSocial';

// Software Author
$author = 'phpSocial';

// Software URL
$url = 'https://phpsocial.com';

// Software Version
$version = '6.8.0';
?>