<?php
// Theme Name
$name = 'Plus';

// Theme Author
$author = 'phpSocial';

// Theme URL
$url = 'https://phpsocial.com';

// Theme Version
$version = '3.6.0';
?>