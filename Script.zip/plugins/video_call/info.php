<?php
// Plugin Name
$name = 'Video Call';

// Plugin Author
$author = 'phpSocial';

// Plugin URL
$url = 'https://phpsocial.com';

// Plugin Version
$version = '1.1.1';

// Plugin Type
$type = '89ed';

// Plugin Priority
$priority = 0;
?>