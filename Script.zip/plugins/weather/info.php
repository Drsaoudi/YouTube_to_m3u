<?php
// Plugin Name
$name = 'Weather';

// Plugin Author
$author = 'phpSocial';

// Plugin URL
$url = 'https://phpsocial.com';

// Plugin Version
$version = '1.0.7';

// Plugin Type
$type = '2389';

// Plugin Priority
$priority = 0;
?>