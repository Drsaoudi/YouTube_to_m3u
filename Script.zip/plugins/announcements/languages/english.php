<?php

$LNG['plugin_announcements_title'] = 'Title';
$LNG['plugin_announcements_content'] = 'Content';
$LNG['plugin_announcements_duration'] = 'Duration';
$LNG['plugin_announcements_type'] = 'Type';
$LNG['plugin_announcements_email_users'] = 'Email Users';
$LNG['plugin_announcements_days'] = 'day(s)';
$LNG['plugin_announcements_save'] = 'Save';
$LNG['plugin_announcements_delete'] = 'Delete';