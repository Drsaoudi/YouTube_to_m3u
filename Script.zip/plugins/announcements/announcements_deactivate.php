<?php

function announcements_deactivate() {
}

?>