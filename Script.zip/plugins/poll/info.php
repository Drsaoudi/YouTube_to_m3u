<?php
// Plugin Name
$name = 'Poll';

// Plugin Author
$author = 'phpSocial';

// Plugin URL
$url = 'https://phpsocial.com';

// Plugin Version
$version = '1.1.2';

// Plugin Type
$type = '189de';

// Plugin Priority
$priority = 100;
?>