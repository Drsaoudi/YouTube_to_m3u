<?php
// Plugin Name
$name = 'File Share';

// Plugin Author
$author = 'phpSocial';

// Plugin URL
$url = 'https://phpsocial.com';

// Plugin Version
$version = '1.2.0';

// Plugin Type
$type = '189ed';

// Plugin Priority
$priority = 100;
?>