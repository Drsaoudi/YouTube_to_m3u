<?php
// Plugin Name
$name = 'Social Share';

// Plugin Author
$author = 'phpSocial';

// Plugin URL
$url = 'https://phpsocial.com';

// Plugin Version
$version = '1.0.8';

// Plugin Type
$type = '789';

// Plugin Priority
$priority = 10;
?>